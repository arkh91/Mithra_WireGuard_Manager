# File: mwg_gui/util.py
# Formatting helpers (bytes, speeds, ages) and a tiny background-work helper so the window never freezes.
# Edit with: vi mwg_gui/util.py
import threading

from PySide6.QtCore import QObject, Signal


def fmt_bytes(n) -> str:
    """
    fmt_bytes(n) -> str
    Usage: fmt_bytes(123456789)    # "123 MB"
    """
    n = float(n or 0)
    units = ["B", "kB", "MB", "GB", "TB", "PB"]
    i = 0
    while n >= 1000 and i < len(units) - 1:
        n /= 1000
        i += 1
    if i == 0:
        return f"{int(n)} B"
    return f"{n:.0f}" + f" {units[i]}" if n >= 100 else (f"{n:.1f}" if n >= 10 else f"{n:.2f}") + f" {units[i]}"


def fmt_rate(bps) -> str:
    """
    fmt_rate(bps) -> str
    Usage: fmt_rate(250000)    # "250 kB/s"
    """
    return fmt_bytes(bps) + "/s"


def wrap_hard(text: str, n: int = 28) -> str:
    """
    wrap_hard(text, n=28) -> str
    Usage: label.setText(wrap_hard(public_key))      # lets a long key without spaces wrap inside a narrow label
    """
    return "\u200b".join(text[i:i + n] for i in range(0, len(text), n)) if len(text) > n else text


def ip_num(ip: str) -> int:
    """
    ip_num(ip) -> int
    Usage: sorted(keys, key=lambda k: ip_num(k["ip"]))
    """
    try:
        a, b, c, d = (int(x) for x in str(ip).split("."))
        return ((a * 256 + b) * 256 + c) * 256 + d
    except ValueError:
        return 0


class _Bridge(QObject):
    """
    _Bridge
    Usage: internal; carries a worker's result back to the window thread.
    """
    done = Signal(object, object)


_bridge = None


def run_async(fn, callback) -> None:
    """
    run_async(fn, callback)
    Usage: run_async(lambda: ctl.create_key(sid, "x"), lambda result: self.after_create(result))
    Runs fn in a background thread; callback(result) runs afterwards in the window thread.
    """
    global _bridge
    if _bridge is None:
        _bridge = _Bridge()
        _bridge.done.connect(lambda cb, res: cb(res))

    def work():
        """
        work()
        Usage: internal thread body
        """
        try:
            res = fn()
        except Exception as exc:                      # never let a worker die silently
            res = {"ok": False, "error": {"code": "errGeneric", "detail": repr(exc)}}
        _bridge.done.emit(callback, res)

    threading.Thread(target=work, daemon=True).start()
