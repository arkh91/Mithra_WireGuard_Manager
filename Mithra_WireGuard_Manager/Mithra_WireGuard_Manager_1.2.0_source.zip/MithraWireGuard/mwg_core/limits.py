# File: core/limits.py
# Traffic limits typed by the user ("20G", "500 MB", "unlimited"), parsed the same way the server's API parses them.
# Edit with: vi core/limits.py
"""
Units are decimal, like the app shows sizes: K M G T = 10^3 .. 10^12 bytes; KiB MiB GiB TiB = 1024^n.
A plain number is bytes. Empty, "0", "unlimited", "none", "off", "no" mean unlimited (0).
"""
import re

MAX_BYTES = 10 ** 18
_RE = re.compile(r"^(\d+(?:[.,]\d+)?)\s*([kmgt]?)(i?)b?$", re.I)
_POW = {"": 0, "k": 1, "m": 2, "g": 3, "t": 4}
_UNLIMITED = {"", "0", "unlimited", "none", "off", "no", "∞", "نامحدود"}


def parse_traffic(text) -> int | None:
    """
    parse_traffic(text) -> int or None
    Usage: parse_traffic("20G")        # 20000000000
           parse_traffic("unlimited")  # 0
           parse_traffic("lots")       # None (not valid)
    """
    if text is None:
        return 0
    if isinstance(text, int):
        return text if 0 <= text <= MAX_BYTES else None
    t = str(text).strip()
    if t.lower() in _UNLIMITED:
        return 0
    m = _RE.match(t)
    if not m:
        return None
    n = round(float(m.group(1).replace(",", ".")) * (1024 if m.group(3) else 1000) ** _POW[m.group(2).lower()])
    return n if 0 <= n <= MAX_BYTES else None


def limit_text(n: int) -> str:
    """
    limit_text(n) -> str
    Usage: edit.setText(limit_text(key["limit"]))    # 20000000000 -> "20G", 1500000000000 -> "1.5T", 0 -> ""
    The short form shown in the edit field; parse_traffic() reads it back to the same number.
    """
    if not n:
        return ""
    for unit, power in (("T", 4), ("G", 3), ("M", 2), ("K", 1)):
        v = n / 1000 ** power
        if v >= 1 and abs(round(v, 3) * 1000 ** power - n) < 1:
            return f"{round(v, 3):.3f}".rstrip("0").rstrip(".") + unit
    return str(n)
