# File: mwg_gui/dialogs.py
# The pop-up windows: ask for text, confirm, replace the access config, and the key window (QR code, config, copy, save).
# Edit with: vi mwg_gui/dialogs.py
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPixmap
from PySide6.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton,
                               QVBoxLayout)

from mwg_core import config
from mwg_core.limits import parse_traffic
from mwg_gui.strings import tr
from mwg_gui.theme import DARK, LIGHT
from mwg_gui.util import paint_titlebar, wrap_hard
from mwg_gui.widgets import label


def button(text: str, kind: str = "") -> QPushButton:
    """
    button(text, kind="") -> QPushButton
    Usage: ok = button("Save", "gold")      # kinds: gold danger (or plain)
    """
    b = QPushButton(text)
    if kind:
        b.setProperty("kind", kind)
    b.setCursor(Qt.PointingHandCursor)
    return b


class Base(QDialog):
    """
    Base(parent, lang, title, width=460)
    Usage: dlg = Base(win, "en", "Rename key"); dlg.body.addWidget(...); dlg.exec()
    A dialog with a heading, a body layout and a button row (dlg.buttons).
    """

    def __init__(self, parent, lang: str, title: str, width: int = 460):
        super().__init__(parent)
        self.lang = lang
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(width)
        self.setWindowFlag(Qt.WindowContextHelpButtonHint, False)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 20)
        root.setSpacing(12)
        root.addWidget(label(title, "h2"))
        self.body = QVBoxLayout()
        self.body.setSpacing(10)
        root.addLayout(self.body)
        self.buttons = QHBoxLayout()
        self.buttons.addStretch(1)
        root.addSpacing(6)
        root.addLayout(self.buttons)

    def showEvent(self, event) -> None:
        """
        showEvent(event)
        Usage: called by Qt when the dialog appears; its title bar follows the window's theme
        """
        super().showEvent(event)
        pal = getattr(self.parent(), "pal", DARK)
        paint_titlebar(self, pal, pal is not LIGHT)

    def add_buttons(self, ok_text: str, kind: str = "gold") -> QPushButton:
        """
        add_buttons(ok_text, kind="gold") -> QPushButton
        Usage: ok = dlg.add_buttons(tr(lang, "save"))   # adds Cancel and the main button
        """
        cancel = button(tr(self.lang, "cancel"))
        cancel.clicked.connect(self.reject)
        ok = button(ok_text, kind)
        ok.clicked.connect(self.accept)
        self.buttons.addWidget(cancel)
        self.buttons.addWidget(ok)
        ok.setDefault(True)
        return ok


def ask_text(parent, lang: str, title: str, placeholder: str = "", initial: str = "", ok_text: str = "") -> str | None:
    """
    ask_text(parent, lang, title, placeholder="", initial="", ok_text="") -> str or None
    Usage: name = ask_text(win, "en", "Rename key", "", "Ali phone")      # None when cancelled
    """
    d = Base(parent, lang, title)
    edit = QLineEdit(initial)
    edit.setPlaceholderText(placeholder)
    edit.setMaxLength(64)
    d.body.addWidget(edit)
    d.add_buttons(ok_text or tr(lang, "save"))
    edit.returnPressed.connect(d.accept)
    edit.setFocus()
    edit.selectAll()
    return edit.text().strip() if d.exec() == QDialog.Accepted else None


def ask_key(parent, lang: str, title: str, name: str = "", traffic: str = "", ok_text: str = "",
            with_limit: bool = True) -> tuple | None:
    """
    ask_key(parent, lang, title, name="", traffic="", ok_text="", with_limit=True) -> (name, traffic) or None
    Usage: r = ask_key(win, "en", "Add a key", ok_text="Create")   # ("Ali phone", "20G"); None when cancelled
    Name and traffic limit of a key. The limit is checked before the dialog closes ("" = unlimited).
    Without with_limit (older server API) only the name is asked.
    """
    d = Base(parent, lang, title)
    d.body.addWidget(label(tr(lang, "keyNameLabel"), "muted"))
    edit = QLineEdit(name)
    edit.setPlaceholderText(tr(lang, "keyNamePh"))
    edit.setMaxLength(64)
    d.body.addWidget(edit)
    lim = None
    err = label("", "bad", wrap=True)
    if with_limit:
        d.body.addWidget(label(tr(lang, "trafficLimit"), "muted"))
        lim = QLineEdit(traffic)
        lim.setPlaceholderText(tr(lang, "trafficPh"))
        lim.setMaxLength(24)
        lim.setLayoutDirection(Qt.LeftToRight)
        d.body.addWidget(lim)
        d.body.addWidget(label(tr(lang, "trafficHint"), "faint", wrap=True))
        err.setVisible(False)
        d.body.addWidget(err)
    ok = d.add_buttons(ok_text or tr(lang, "save"))
    ok.clicked.disconnect()

    def done():
        """
        done()
        Usage: the main button / Enter; closes only with a valid limit
        """
        if lim is not None and parse_traffic(lim.text()) is None:
            err.setText(tr(lang, "errBadTraffic"))
            err.setVisible(True)
            lim.setFocus()
            return
        d.accept()

    ok.clicked.connect(done)
    edit.returnPressed.connect(done)
    if lim is not None:
        lim.returnPressed.connect(done)
    edit.setFocus()
    edit.selectAll()
    if d.exec() != QDialog.Accepted:
        return None
    return edit.text().strip(), (lim.text().strip() if lim is not None else "")


def confirm(parent, lang: str, title: str, body: str, ok_text: str, danger: bool = True) -> bool:
    """
    confirm(parent, lang, title, body, ok_text, danger=True) -> bool
    Usage: if confirm(win, "en", "Remove this key?", "It stops working.", "Remove"): ...
    """
    d = Base(parent, lang, title)
    d.body.addWidget(label(body, "muted", wrap=True))
    d.add_buttons(ok_text, "danger" if danger else "gold")
    return d.exec() == QDialog.Accepted


def ask_access(parent, lang: str, title: str, body: str, check) -> str | None:
    """
    ask_access(parent, lang, title, body, check) -> str or None
    Usage: text = ask_access(win, "en", "Replace the access config", "Paste ...", ctl.check_access)
    A paste box for an access config with a live check line; the main button stays off until it is understood.
    """
    d = Base(parent, lang, title, 560)
    d.body.addWidget(label(body, "muted", wrap=True))
    box = QPlainTextEdit()
    box.setFixedHeight(120)
    box.setPlaceholderText(tr(lang, "pastePh"))
    d.body.addWidget(box)
    msg = label("", "faint", wrap=True)
    d.body.addWidget(msg)
    ok = d.add_buttons(tr(lang, "save"))
    ok.setEnabled(False)

    def changed():
        """
        changed()
        Usage: connected to the paste box
        """
        t = box.toPlainText().strip()
        if not t:
            msg.setText("")
            ok.setEnabled(False)
            return
        r = check(t)
        ok.setEnabled(bool(r.get("ok")))
        if r.get("ok"):
            msg.setText("✓ " + tr(lang, "okOutline" if r["format"] == "outline" else "okToken") + " • " +
                        tr(lang, "okPinned" if r["pinned"] else "okCa"))
        else:
            msg.setText(tr(lang, r["error"]["code"]))

    box.textChanged.connect(changed)
    return box.toPlainText().strip() if d.exec() == QDialog.Accepted else None


def qr_pixmap(text: str, size: int = 230) -> QPixmap:
    """
    qr_pixmap(text, size=230) -> QPixmap
    Usage: label.setPixmap(qr_pixmap(key["config"]))
    A QR code drawn module by module with QPainter (no SVG renderer needed, so it also works in the installed app),
    on a white tile with a quiet zone so every phone camera can read it. If drawing fails, the error text is printed on the tile.
    """
    pm = QPixmap(size, size)
    pm.fill(QColor("white"))
    try:
        from mwg_core._vendor import segno
        rows = [list(r) for r in segno.make(text, error="l", micro=False).matrix]
    except Exception as e:  # noqa: BLE001 - say what went wrong on the tile instead of crashing the dialog
        p = QPainter(pm)
        p.setPen(QColor("#b00020"))
        p.drawText(pm.rect().adjusted(12, 12, -12, -12), Qt.TextWordWrap, "QR code failed: " + repr(e))
        p.end()
        return pm
    n = len(rows)
    quiet = 4
    cell = size / (n + 2 * quiet)
    p = QPainter(pm)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor("#000000"))
    for y, row in enumerate(rows):
        for x, v in enumerate(row):
            if v:
                # round the edges outwards so neighbouring modules never leave hairlines
                x0, y0 = int((x + quiet) * cell), int((y + quiet) * cell)
                x1, y1 = int((x + quiet + 1) * cell + 0.999), int((y + quiet + 1) * cell + 0.999)
                p.drawRect(x0, y0, x1 - x0, y1 - y0)
    p.end()
    return pm


class KeyDialog(Base):
    """
    KeyDialog(parent, lang, key, toast, legacy=False)
    Usage: KeyDialog(win, "en", detail["key"], win.toast_text, legacy=False).exec()   # legacy: the server is still on the old API
    One key: QR code for the WireGuard phone app, the facts, the config text, Copy and Save .conf.
    """

    def __init__(self, parent, lang: str, key: dict, toast, legacy: bool = False):
        super().__init__(parent, lang, key["name"] or tr(lang, "unnamed"), 640)
        self.key, self.toast = key, toast
        top = QHBoxLayout()
        top.setSpacing(18)
        left = QVBoxLayout()
        qr = QLabel()
        if key["config"]:
            qr.setPixmap(qr_pixmap(key["config"]))
            left.addWidget(qr)
            left.addWidget(label(tr(lang, "scanQr"), "faint", wrap=True))
        else:
            if legacy:
                left.addWidget(label(tr(lang, "noConfig"), "muted", wrap=True))
                cmd = QPlainTextEdit(config.UPDATE_API_COMMAND)
                cmd.setReadOnly(True)
                cmd.setFixedHeight(76)
                cmd.setStyleSheet("font-family:'Cascadia Mono','Consolas',monospace;font-size:11px;")
                left.addWidget(cmd)
                cpc = button(tr(lang, "copy"))
                cpc.clicked.connect(lambda: (QGuiApplication.clipboard().setText(config.UPDATE_API_COMMAND), self.toast(tr(lang, "copied"))))
                left.addWidget(cpc, 0, Qt.AlignLeft)
            else:
                left.addWidget(label(tr(lang, "noConfigNew"), "muted", wrap=True))
        left.addStretch(1)
        top.addLayout(left)
        facts = QVBoxLayout()
        facts.setSpacing(2)
        for k, v in ((tr(lang, "address"), key["address"]), (tr(lang, "publicKey"), key["publicKey"]),
                     (tr(lang, "allowedIPs"), key["allowedIPs"]), (tr(lang, "endpoint"), key["endpoint"]),
                     (tr(lang, "dns"), key["dns"]), (tr(lang, "created"), key["createdAt"])):
            if v:
                facts.addWidget(label(k, "faint"))
                lv = label(wrap_hard(str(v), 34), "mono", wrap=True)
                lv.setTextInteractionFlags(Qt.TextSelectableByMouse)
                facts.addWidget(lv)
        facts.addStretch(1)
        top.addLayout(facts, 1)
        self.body.addLayout(top)
        if key["config"]:
            self.box = QPlainTextEdit(key["config"])
            self.box.setReadOnly(True)
            self.box.setFixedHeight(150)
            self.box.setStyleSheet("font-family:'Cascadia Mono','Consolas',monospace;font-size:12px;")
            self.body.addWidget(self.box)
            cp = button(tr(lang, "copyConfig"))
            cp.clicked.connect(self.copy)
            sv = button(tr(lang, "saveConf"), "gold")
            sv.clicked.connect(self.save)
            self.buttons.insertWidget(0, cp)
            self.buttons.insertWidget(1, sv)
            share = QHBoxLayout()
            share.addWidget(label(tr(lang, "share") + ":", "faint"))
            for text, fn in ((tr(lang, "copyQr"), self.copy_qr), (tr(lang, "saveQr"), self.save_qr)):
                b = button(text)
                b.clicked.connect(fn)
                share.addWidget(b)
            share.addStretch(1)
            self.body.addLayout(share)
        close = button(tr(lang, "close"))
        close.clicked.connect(self.accept)
        self.buttons.addWidget(close)

    def copy(self) -> None:
        """
        copy()
        Usage: connected to the Copy config button
        """
        QGuiApplication.clipboard().setText(self.key["config"])
        self.toast(tr(self.lang, "copied"))

    def copy_qr(self) -> None:
        """
        copy_qr()
        Usage: Copy QR image button; paste the picture into a chat or an e-mail
        """
        QGuiApplication.clipboard().setPixmap(qr_pixmap(self.key["config"], 520))
        self.toast(tr(self.lang, "copied"))

    def save_qr(self) -> None:
        """
        save_qr()
        Usage: Save QR button; writes a PNG of the QR code
        """
        stem = self.key["fileName"].rsplit(".", 1)[0]
        path, _ = QFileDialog.getSaveFileName(self, tr(self.lang, "saveQr"), stem + ".png", "PNG (*.png)")
        if path:
            qr_pixmap(self.key["config"], 520).save(path, "PNG")
            self.toast(tr(self.lang, "saved"))

    def save(self) -> None:
        """
        save()
        Usage: connected to the Save .conf button
        """
        path, _ = QFileDialog.getSaveFileName(self, tr(self.lang, "saveConf"), self.key["fileName"], "WireGuard (*.conf)")
        if path:
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(self.key["config"])
            self.toast(tr(self.lang, "saved"))
