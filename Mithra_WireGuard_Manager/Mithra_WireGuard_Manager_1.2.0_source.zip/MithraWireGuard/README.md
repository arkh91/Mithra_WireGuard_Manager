<!-- File: README.md  -  Edit with: vi README.md -->
# Mithra WireGuard Manager

A Windows app for the WireGuard servers installed with `install-wg-full.sh`, made to work like Outline Manager:
paste a server's access config, press **Done**, and every key is listed with its usage, last handshake and config.
You can add, rename and remove keys, show a key's QR code for the WireGuard phone app, save a `.conf` file, or
export every config of a server at once.

## 1. Update the server (once per server)

The app already works with servers on the previous API (it reads `/access-keys` or `/keys`, and falls back to
`/usage` on very old ones). To get the Outline-style routes as well, update the API; keys and peers are untouched:

    curl -fsSLo install-wg-full.sh https://raw.githubusercontent.com/arkh91/Arkh91_WireGuard/v2.1.1/install-wg-full.sh
    sha256sum install-wg-full.sh        # must match the release notes / the command the app shows
    sudo bash install-wg-full.sh --update-api

`--update-api` also moves the server to the new firewall (clients isolated from each other and from private and
cloud-metadata networks, suspensions always applied first) and sends IPv6 into the tunnel. Devices that imported a
key before the update should re-import its config once.

It prints both access configs. They are also saved on the server:

    sudo cat /etc/wg-api/access.json            {"apiUrl":"https://host:2053","apiToken":"...","certSha256":"..."}
    sudo cat /etc/wg-api/access-outline.json    {"apiUrl":"https://host:2053/<secret>","certSha256":"..."}

The second one is exactly Outline's format: the secret is the last part of `apiUrl`, and
`GET <apiUrl>/access-keys` returns every key with no header.

## 2. Add the server in the app

Install `Mithra_WireGuard_Manager_Setup_1.2.0.exe`, open the app, choose **Add server**, paste either access config (extra
text around it is fine) and press **Done**. The app connects, checks the certificate and pulls the keys before it
saves anything.

## Certificate check (certSha256)

Like Outline Manager, the app hashes the certificate the server presents (SHA-256 of the DER bytes, what
`openssl x509 -fingerprint -sha256` prints) and compares it with `certSha256` before it sends the token. On a
mismatch it stops and shows both fingerprints. If a reinstall gave the server a new certificate, use
**Replace access config** on that server. Without `certSha256` (a Let's Encrypt certificate) the normal Windows
CA check is used.

## Pause and traffic limits (API 2.1)

Each key row has a **pause** button (a paused key stays configured but no traffic passes) and the pencil opens
**Edit key** with the name and a **traffic limit** such as `20G`, `500M` or `1.5T` (empty = unlimited). The limit
counts upload + download since the key was created; a key that reaches it is blocked (red **Limit reached**) until the
limit is raised or removed. The **Paused** filter lists paused and over-limit keys. Servers on API 2.0 show a banner
with the update command instead of these buttons.

## API routes (server.js, API 2.1)

| Route | What it does |
|---|---|
| `GET /` and `GET /keys` | every key: `{server, count, totals, keys:[...]}` |
| `GET /access-keys` | the same list as `accessKeys` (Outline's name) |
| `GET /keys/<ip>` | one key |
| `POST /create?format=json` or `POST /access-keys` | new key, body `{"name": "..."}` (201 for `/access-keys`) |
| `POST /remove` `{"ipAddress": ip}` or `DELETE /access-keys/<ip>` | remove a key (204 for `DELETE`) |
| `PUT /access-keys/<ip>/name` | rename, body `{"name": "..."}` |
| `POST /create` with `{"ipAddress": "10.66.0.2", "traffic": "20G"}` | new key at a chosen address with a limit (both optional) |
| `POST /keys/<ip>/pause`, `POST /keys/<ip>/resume` | pause / resume a key (also `PUT /keys/<ip>/paused {"paused": true}`) |
| `PUT /keys/<ip>/limit {"traffic": "20G"}`, `DELETE /keys/<ip>/limit` | set / remove the traffic limit (`"unlimited"` works too; Outline's `PUT /access-keys/<ip>/data-limit {"limit":{"bytes":N}}` as well) |
| `GET /server` | public server facts, `apiVersion`, key count |
| `GET /metrics/transfer` | `{bytesTransferredByUserId: {ip: bytes}}` |
| `GET /usage[/<ip>]` | upload, download, last handshake |
| `GET /health` | public, and also under the secret path |

Each key carries `privateKey, publicKey, address, dns, endpoint, allowedIPs, persistentKeepalive, createdAt,
uploadBytes, downloadBytes, totalBytes, lastHandshake, name, paused, dataLimitBytes, limitReached, status` and a ready `config` (null for keys whose private key
the server never saw).

## Where the app keeps things

`%LOCALAPPDATA%\MithraWireGuard\` - `servers.json` (access configs encrypted with DPAPI for your Windows account),
`settings.json`, `logs\app.log`. Tokens, secret paths and private keys are never written to the log.
