<!-- File: README.md  -  Edit with: vi README.md -->
# Mithra WireGuard Manager

A Windows app for the WireGuard servers installed with `install-wg-full.sh`, made to work like Outline Manager:
paste a server's access config, press **Done**, and every key is listed with its usage, last handshake and config.
You can add, rename and remove keys, show a key's QR code for the WireGuard phone app, save a `.conf` file, or
export every config of a server at once.

## 1. Update the server (once per server)

The app already works with servers on the previous API (it reads `/access-keys` or `/keys`, and falls back to
`/usage` on very old ones). To get the Outline-style routes as well, update the API; keys and peers are untouched:

    sudo bash install-wg-full.sh --update-api

It prints both access configs. They are also saved on the server:

    sudo cat /etc/wg-api/access.json            {"apiUrl":"https://host:2053","apiToken":"...","certSha256":"..."}
    sudo cat /etc/wg-api/access-outline.json    {"apiUrl":"https://host:2053/<secret>","certSha256":"..."}

The second one is exactly Outline's format: the secret is the last part of `apiUrl`, and
`GET <apiUrl>/access-keys` returns every key with no header.

## 2. Add the server in the app

Install `Mithra_WireGuard_Manager_Setup_1.1.0.exe`, open the app, choose **Add server**, paste either access config (extra
text around it is fine) and press **Done**. The app connects, checks the certificate and pulls the keys before it
saves anything.

## Certificate check (certSha256)

Like Outline Manager, the app hashes the certificate the server presents (SHA-256 of the DER bytes, what
`openssl x509 -fingerprint -sha256` prints) and compares it with `certSha256` before it sends the token. On a
mismatch it stops and shows both fingerprints. If a reinstall gave the server a new certificate, use
**Replace access config** on that server. Without `certSha256` (a Let's Encrypt certificate) the normal Windows
CA check is used.

## API routes (server.js, API 2.0)

| Route | What it does |
|---|---|
| `GET /` and `GET /keys` | every key: `{server, count, totals, keys:[...]}` |
| `GET /access-keys` | the same list as `accessKeys` (Outline's name) |
| `GET /keys/<ip>` | one key |
| `POST /create?format=json` or `POST /access-keys` | new key, body `{"name": "..."}` (201 for `/access-keys`) |
| `POST /remove` `{"ipAddress": ip}` or `DELETE /access-keys/<ip>` | remove a key (204 for `DELETE`) |
| `PUT /access-keys/<ip>/name` | rename, body `{"name": "..."}` |
| `GET /server` | public server facts, `apiVersion`, key count |
| `GET /metrics/transfer` | `{bytesTransferredByUserId: {ip: bytes}}` |
| `GET /usage[/<ip>]` | upload, download, last handshake |
| `GET /health` | public, and also under the secret path |

Each key carries `privateKey, publicKey, address, dns, endpoint, allowedIPs, persistentKeepalive, createdAt,
uploadBytes, downloadBytes, totalBytes, lastHandshake, name` and a ready `config` (null for keys whose private key
the server never saw).

## Where the app keeps things

`%LOCALAPPDATA%\MithraWireGuard\` - `servers.json` (access configs encrypted with DPAPI for your Windows account),
`settings.json`, `logs\app.log`. Tokens, secret paths and private keys are never written to the log.
