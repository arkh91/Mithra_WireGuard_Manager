# File: tests/test_pause_limit.py
# Pause/resume and traffic limits: the parser, and the controller against the REAL server.js (devtools/test_server.py).
# Edit with: vi tests/test_pause_limit.py
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

from mwg_core.limits import limit_text, parse_traffic

ROOT = Path(__file__).resolve().parent.parent


@pytest.mark.parametrize("text,value", [
    ("20G", 20_000_000_000), ("20 GB", 20_000_000_000), ("500m", 500_000_000), ("1.5T", 1_500_000_000_000),
    ("1,5G", 1_500_000_000), ("2GiB", 2 * 1024 ** 3), ("12345", 12345), ("", 0), ("unlimited", 0), ("0", 0),
    ("نامحدود", 0), (None, 0), ("lots", None), ("-5G", None), ("20X", None), ("2" * 30, None),
])
def test_parse_traffic(text, value):
    """
    test_parse_traffic(text, value)
    Usage: pytest -k parse_traffic
    """
    assert parse_traffic(text) == value


@pytest.mark.parametrize("n", [0, 20_000_000_000, 1_500_000_000_000, 500_000_000, 12345, 2 * 1024 ** 3])
def test_limit_text_round_trip(n):
    """
    test_limit_text_round_trip(n)
    Usage: pytest -k round_trip     # what the edit field shows reads back as the same number
    """
    assert parse_traffic(limit_text(n)) == n


def _free_port() -> int:
    """
    _free_port() -> int
    Usage: port = _free_port()
    """
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def real_api(tmp_path_factory):
    """
    real_api(tmp_path_factory) -> access config text
    Usage: def test_x(real_api): ctl.add_server(real_api)
    Starts devtools/test_server.py (real server.js, fake helper) on a free port; skipped without node/npm.
    """
    if not (shutil.which("node") and shutil.which("npm") and shutil.which("openssl")):
        pytest.skip("node, npm and openssl are needed")
    d = tmp_path_factory.mktemp("api")
    port, internal = _free_port(), _free_port()
    env = dict(os.environ, NO_PROXY="localhost,127.0.0.1", no_proxy="localhost,127.0.0.1")
    p = subprocess.Popen([sys.executable, str(ROOT / "devtools" / "test_server.py"), "--port", str(port), "--internal",
                          str(internal), "--keys", "4", "--dir", str(d)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, env=env)
    cfg = ""
    t0 = time.time()
    while time.time() - t0 < 180:
        line = p.stdout.readline()
        if line.startswith("TOKEN"):
            cfg = line.split(None, 1)[1].strip()
        if "wg-api listening" in line and cfg:
            break
        if p.poll() is not None:
            break
    if not cfg:
        p.kill()
        pytest.skip("test server did not start")
    yield cfg
    p.terminate()
    p.wait(10)


def test_pause_resume_and_limits_on_real_api(real_api, tmp_path):
    """
    test_pause_resume_and_limits_on_real_api(real_api, tmp_path)
    Usage: pytest -k real_api
    """
    from tests.core_paths import make
    ctl = make(tmp_path)
    r = ctl.add_server(real_api, "Real")
    assert r["ok"], r
    sid = r["sid"]
    assert {"pause", "limit"} <= set(ctl.features(sid))
    assert ctl.state()["server"]["paused"] == 1                 # the fake server starts with one paused key

    r = ctl.create_key(sid, "Phone", "20G")
    assert r["ok"], r
    ip = r["result"]["ip"]
    k = next(k for k in ctl.keys(sid)["keys"] if k["ip"] == ip)
    assert k["limit"] == 20_000_000_000 and not k["paused"] and not k["limitReached"]

    assert ctl.set_paused(sid, ip, True)["ok"]
    assert next(k for k in ctl.keys(sid)["keys"] if k["ip"] == ip)["paused"]
    assert ctl.set_paused(sid, ip, False)["ok"]
    assert not next(k for k in ctl.keys(sid)["keys"] if k["ip"] == ip)["paused"]

    assert ctl.edit_key(sid, ip, "Phone 2", "1K")["ok"]         # below its usage once traffic flows
    k = next(k for k in ctl.keys(sid)["keys"] if k["ip"] == ip)
    assert k["name"] == "Phone 2" and k["limit"] == 1000
    assert ctl.edit_key(sid, ip, "Phone 2", "")["ok"]           # unlimited
    assert next(k for k in ctl.keys(sid)["keys"] if k["ip"] == ip)["limit"] == 0

    assert ctl.edit_key(sid, ip, "Phone 2", "lots")["error"]["code"] == "errBadTraffic"
    assert ctl.create_key(sid, "x", "20X")["error"]["code"] == "errBadTraffic"
    assert ctl.set_paused(sid, "10.66.0.250", True)["error"]["code"] == "errNoKey"


def test_old_api_has_no_pause(tmp_path):
    """
    test_old_api_has_no_pause(tmp_path)
    Usage: pytest -k old_api_has_no_pause    # a server without the features list: pause/limit refused locally
    """
    from tests.core_paths import make
    ctl = make(tmp_path)
    ctl.servers["x"] = type("S", (), {"server": {}})()
    assert ctl.set_paused("x", "10.66.0.2", True)["error"]["code"] == "errOldApi"
    assert ctl.create_key("x", "a", "20G")["error"]["code"] == "errOldApi"


def test_config_commands_are_pinned():
    """
    test_config_commands_are_pinned()
    Usage: pytest -k pinned     # the commands the app shows run one tagged file after checking its SHA-256
    """
    from mwg_core import config
    assert "refs/heads/main" not in config.INSTALL_COMMAND
    assert "sha256sum -c" in config.UPDATE_API_COMMAND and config.SERVER_SCRIPT_TAG in config.UPDATE_API_COMMAND
    assert json.dumps(config.UPDATE_API_COMMAND)
